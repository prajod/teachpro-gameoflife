package prog.assignment.gol;

import java.util.List;

public interface InputHandler {
	public void setInputSource(Object inputSource); 
	public List<String> parseInput(String input);
	public void setInput(List<String> list);
}
