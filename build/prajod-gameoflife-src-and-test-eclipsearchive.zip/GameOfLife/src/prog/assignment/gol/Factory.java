package prog.assignment.gol;

/**
 * The interface for the Abstract Factory class for the Game of Life program. 
 * 
 * @author prajod
 *
 */

public interface Factory {

}
