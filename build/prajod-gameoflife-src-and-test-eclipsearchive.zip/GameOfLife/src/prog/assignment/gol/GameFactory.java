/**
 * This abstract factory class can be used to create different families of
 * objects for the GameOfLife program. 
 */
package prog.assignment.gol;

/**
 * @author prajod
 *
 */
public abstract class GameFactory implements Factory {

}
