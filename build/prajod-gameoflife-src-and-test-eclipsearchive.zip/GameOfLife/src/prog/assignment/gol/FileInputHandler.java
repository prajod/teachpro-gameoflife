package prog.assignment.gol;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Class to read the generation data from a file.
 * @author prajod
 *
 */
public class FileInputHandler implements InputHandler {
	
	List<String> list;
	Object reader;
	
	
	public void setInputSource(Object inputSource){
		reader = inputSource;
	}
	
	/**
	 * Parses the input file and create a list of string containing the input rows.
	 * Each entry in the list represents a line in the file
	 * @param String fileName
	 * The path and name of the file to read the first generation from
	 */
	public List<String> parseInput(String fileName){
		BufferedReader inputReader;
		try {
			inputReader = new BufferedReader(new FileReader(fileName));
		} catch (FileNotFoundException e) {
			Logger.logLine(Logger.INFO, "Unable to locate input file: " +e.getMessage());
			return null;
		}
		Logger.logLine(Logger.INFO, "Input file name is: "+fileName);
		List<String> inputDataList = new ArrayList<String>();
		
		String line;
		try {
			line = inputReader.readLine();
		
			while(line != null){
				inputDataList.add(line);
				line = inputReader.readLine();
			}
			inputReader.close();
		} catch (IOException e) {
			Logger.log(Logger.INFO, "Error while reading input file: " +e.getMessage());
			return null;
		}
		return inputDataList;
	}

	public void setInput(List<String> list){
			this.list = list;
	}
}
