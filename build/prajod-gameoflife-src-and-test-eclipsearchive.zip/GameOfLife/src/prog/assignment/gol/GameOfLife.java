/**
 * This program is an implementation of cellular automation called the 
 * <bold> Game of Life </bold>. It was invented by John Conway in 1970.
 * The context of the game:
 * <ul>
 * 	<li> The game starts with an initial block of cells arranged in a rectangle</li>
 * 	<li> Each cell in the block can have two states: alive or dead</li>
 * 	<li> The succeeding generation is derived by applying the rules of evolution to each cell</li>
 * </ul>
 * <ul>
 * The evolution rules:
 * 	<li> Each cell <i>lives,</i> <i>dies</i> or <i>rises from the dead,</i> in the next generation based on the state of its
 * neighbours in the current generation</li>
 *  <li> If a cell has more than 3 live neighbours, it will die due to overcrowding </li>
 *  <li> If a dead cell has exactly 3 live neighbours, it will become alive</li>
 *  <li> If a cell has two live neighbours, it will not change state in the next generation</li>
 *  <li> If a cell has less than two live neighbours, it will die in the next generation</li>
 *  <li> </li>
 * </ul>
 */
package prog.assignment.gol;

import java.util.LinkedList;
import java.util.List;

import prog.assignment.gol.board.Board;
import prog.assignment.gol.board.Cell;
import prog.assignment.gol.board.BoardFactory;
import prog.assignment.gol.board.Point;

/**
 * @author prajod
 *
 */
public class GameOfLife {
	
	public static void main(String[] args){
		if(args.length < 3){
			printUsage();
			return;
		}
		
		try {
			int xSize = Integer.parseInt(args[0]);
			int ySize = Integer.parseInt(args[1]);
			String fileName = args[2];
			int gen = 1;
			if(args.length > 3) gen = Integer.parseInt(args[3]);
			
			InputHandler inputHandler = new FileInputHandler();
			List<String> inputDataList = inputHandler.parseInput(fileName);
			
			if (inputDataList == null){
				Logger.logLine(Logger.INFO, "Input file is empty");
				printUsage();
				return;
			}
			Logger.log(Logger.DEBUG, inputDataList.toArray().toString());
			GameOfLife game = new GameOfLife();
			Board result = game.processGens(xSize, ySize, gen, inputDataList);
			Logger.logLine(Logger.DEBUG,"Generation " + gen + " board");
			result.display();
					
		} catch (NumberFormatException e){
			Logger.logLine(Logger.INFO,"Incorrect inputs");
			printUsage();
		}
		
	
	}
	
	public Board processGens(int xSize, int ySize, int noOfGen, List<String> input){
		Logger.logLine(Logger.INFO,"Inputs - x:" + xSize + " y: " + ySize + " No. of Gen:" + noOfGen);
		Board board = BoardFactory.getBoard(IConstants.CURRENT_BOARD);
		board.initializeFromSize(xSize,ySize);
		board.copyStateFrom(input);
		
		Logger.logLine(Logger.INFO,"Initial board : ");
		board.display();
		
		List<Point> modifiedCells = new LinkedList<Point>();
		Board newBoard = null;
		
		for(int i = 0; i < noOfGen; i++){
			//Increase board size by one row on all sides
			xSize = board.getXSize() + 2;
			ySize = board.getYSize() + 2;
			newBoard = BoardFactory.getBoard(IConstants.CURRENT_BOARD);
			newBoard.initializeFromSize(xSize, ySize);
			newBoard.copyStateFrom(board);
			
			//Logger.logLine(Logger.INFO,"Generation " + i + " board");
			//newBoard.display();
			
			for(int x = 0; x < xSize; x++){
				for(int y = 0; y < ySize; y++){
					Cell cell = newBoard.getCell(x, y);
					int nCount = cell.getNeighbourCount();
					//Logger.logLine("No. of neighbours of [" + x + "," + y + "] : " + nCount);
					
					//No change for n=2 or n=3 and alive
					if(nCount == 2 || 
					   (nCount == 3 && cell.isAlive())) continue;
					
					//Alive if n=3 
					if(nCount == 3 && cell.isDead()) {
						modifiedCells.add(cell.getPosition());
						continue;
					}
					
					//All others should be dead
					if(cell.isAlive()) modifiedCells.add(cell.getPosition());
				}
			}
			
			//Logger.logLine(Logger.DEBUG,"Modified cells : " + modifiedCells.toString());
			for(Point mPosition : modifiedCells){
				Cell mCell = newBoard.getCell(mPosition.x, mPosition.y);
				mCell.switchState();
			}
			
			modifiedCells.clear();
			//Logger.logLine(Logger.DEBUG, "Before Pruning");
			//newBoard.display();
			newBoard.pruneBoard();
			//Logger.logLine(Logger.DEBUG, "After Pruning");
			//newBoard.display();
			board = newBoard;
		}
		
		return newBoard;
	}
	

	
	public static void printUsage() {
		Logger.logLine(
				Logger.DEBUG,
				"This is the Game of Life program. It can take up to 4 arguments:" +
				"<nCols> is a required argument. It is the number of columns in the input file" +
				"<nRows> is a required argument. It is the number of rows in the input file" +
				"<input file path> is a required argument. It is the path and file name which had the first generation of cells" +
				"[no of generations] is an optional argument. It is the number of geerations to process after the first generation. It defaults to 1, if not provded" +
				"Usage : GameOfLife <nCols> <nRows> <input file path> [no of generations]");
	}
	


}
