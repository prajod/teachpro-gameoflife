package prog.assignment.gol.board;

import java.util.List;

import prog.assignment.gol.IConstants;
import prog.assignment.gol.Logger;

/**
 * Board implemented as a 2 dimensional ArrayList
 * @author prajod
 *
 */
public class ArrayListBoard extends AbstractBoard{

	
	public static Board getInstance() {
		return new ArrayListBoard();
	}

	private ListOfList cellMatrix;
	
	/**
	 * Private constructor for enabling factory based creation
	 */
	private ArrayListBoard(){
	}
	
	public Board initializeFromSize(int xSize, int ySize){
		//Logger.logLine(Logger.DEBUG, "Initializing new board of size " + xSize + "," + ySize);
		
		cellMatrix = new ListOfList(xSize,ySize); 
		
		//add all neighbours for all cells		
		for(int x = 0; x < xSize; x++){
			for(int y = 0; y < ySize; y++){		
				for(int i = x-1; i <= x+1; i++){
					for(int j = y-1; j <= y+1; j++){
						if(i == x && j==y) continue;
						if( i < 0 || j < 0 ||
							i >= xSize || j >= ySize) continue;
						//Logger.logLine("Neighbour of [" + x + ',' + y + ']' + '[' + i + ',' + j + ']');
						cellMatrix.getCell(x,y).addNeighbour(getCell(i,j));
					}
				}
			}
		}
	    return this;
	}
	
	public int getXSize() {
		return cellMatrix.getXSize();
	}

	public int getYSize() {
		return cellMatrix.getYSize();
	}
	
	/**
	 * Get the cell object at the [x,y]th location
	 */
	public Cell getCell(int x, int y){
		return cellMatrix.getCell(x,y);
	}
	

	/**
	 * Copies the state to this board from the List given as argument
	 * @param List dataList 
	 * The source list of strings, which has the state to be copied from.
	 * This list is a list of strings, with each string representing the state of each row.
	 * @return The board, with the new state copied from the argument list, in each cell.
	 */
	@Override
	public Board copyStateFrom(List<String> dataList){
		for(int y = 0; y<getYSize() && y<dataList.size(); y++){
			String row = dataList.get(y);
			String [] rowElements = row.split(IConstants.SEPARATOR);
			for(int x = 0; x<getXSize() && x<rowElements.length; x++){
				if(rowElements[x].equals(IConstants.ALIVE_CHAR)){
					getCell(x,y).setState(true);
				}
			}
		}
		return this;
	}
	
	/**
	 * Copies the state to this board from the board given as argument
	 * @param Board board 
	 * The source board which has the original state
	 * @return 
	 * The board, with the new state copied from the argument board, in each cell.
	 */
	@Override
	public Board copyStateFrom(Board board){
		//The prev generation board is 2 sizes smaller
		for(int i = 0; i < getXSize()-2; i++){
			for(int j = 0; j < getYSize()-2; j++){
				if(board.getCell(i, j).getState()){
					getCell(i+1,j+1).setState(true);
				}
			}
		}
		return this;
	}
	
	@Override
	public void pruneBoard(){
		cellMatrix.prune();
	}
	
	@Override
	public String display(){
		StringBuffer result = new StringBuffer();
		
		for(int y = 0; y < getYSize(); y++){
			StringBuffer line = new StringBuffer();
			for(int x = 0; x < getXSize(); x++){
				if(getCell(x,y).isAlive()){
					line.append(IConstants.ALIVE_CHAR).append(' ');
					Logger.log(Logger.DEBUG, IConstants.ALIVE_CHAR + " ");
				} else {
					line.append(IConstants.DEAD_CHAR).append(' ');
					Logger.log(Logger.DEBUG, IConstants.DEAD_CHAR + " ");
				}
			}
			Logger.log(Logger.DEBUG, "\n");
			result.append(line.toString()).append("\n");
		}
		
		return result.toString();
	}
	
	/**
	 * Creates a string representation of this board
	 */
	public String toString(){
		return cellMatrix.toString();
	}
	
}
