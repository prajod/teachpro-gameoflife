package prog.assignment.gol.board;

import java.util.LinkedList;
import java.util.List;

/**
 * This class represents the state of each cell in the Board. It also holds
 * a list containing the coordinates of its neighbors.
 * @author prajod
 *
 */
public class Cell {
	
	private Point position;
	private boolean state = false;
	
	private List<Cell> neighbours = new LinkedList<Cell>();
	
	public static Cell geInstance(int x, int y){
		return new Cell(x,y);
	}
	
	public Cell(int x, int y){
		setPoint(x,y);
	}
	
	public void setPoint(int x, int y){
		position = new Point(x, y);
	}

	public Point getPosition(){
		return position;
	}
	
	public void setState(boolean state){
		this.state = state;
	}
	
	public void switchState(){
		if (state == false) state = true;
		else if (state == true) state = false;
	}
	
	public boolean getState(){
		return state;
	}
	
	public boolean isAlive(){
		return state;
	}
	
	public boolean isDead(){
		return !state;
	}
	
	public void addNeighbour(Cell cell){
		neighbours.add(cell);
	}
	
	public int getNeighbourCount(){
		int nCount = 0;
		for(Cell neighbour: neighbours){
			if(neighbour.getState()){
				nCount++;
			}
		}
		return nCount;
	}
	
	public String toString(){
		StringBuffer strBuffer =  new StringBuffer();
		strBuffer.append("Cell: "+ "Position = "+position.toString());
		strBuffer.append(" State = " + (state? "Alive":"Dead"));
		strBuffer.append(" Neighbours = "+neighbours);
		
		return strBuffer.toString();
	}
}
