package prog.assignment.gol.board;

public abstract class AbstractBoard implements Board {
}
