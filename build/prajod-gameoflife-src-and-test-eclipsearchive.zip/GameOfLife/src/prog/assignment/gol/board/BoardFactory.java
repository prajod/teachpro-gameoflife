package prog.assignment.gol.board;

import prog.assignment.gol.GameFactory;
import prog.assignment.gol.IConstants;

public abstract class BoardFactory extends GameFactory {
	
	public abstract BoardFactory getInstance();
	
	public static Board getBoard(String strBoard){
		if (strBoard == null) return null;
		
		if (strBoard.equals(IConstants.ARRAY_BOARD))
			return  ArrayBoard.getInstance();
		if (strBoard.equals(IConstants.ARRAY_LIST_BOARD))
			return ArrayListBoard.getInstance();
		else
			return  ArrayBoard.getInstance();
	}	
	

}
