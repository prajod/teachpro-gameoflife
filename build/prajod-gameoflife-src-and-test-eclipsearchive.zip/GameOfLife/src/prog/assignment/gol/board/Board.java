package prog.assignment.gol.board;

import java.util.List;


public interface Board {
	public int getXSize();
	public int getYSize();
	public Board copyStateFrom(List<String> list);
	public Board initializeFromSize(int xSize, int ySize);
	public Board copyStateFrom(Board board);
	public Cell getCell(int x, int y);
	public String display();
	public void pruneBoard();
	public String toString();
}
