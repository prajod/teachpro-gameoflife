package prog.assignment.gol.board;

import java.util.List;

import prog.assignment.gol.IConstants;
import prog.assignment.gol.Logger;

/**
 * Board implemeted as a 2 dimensional array.
 * @author prajod
 *
 */
public class ArrayBoard extends AbstractBoard{

	
	public static Board getInstance() {
		return new ArrayBoard();
	}

	private Cell [][] cellMatrix;
	
	private int xSize;
	
	private int ySize;
	
	/**
	 * Private constructor for enabling factory based creation
	 */
	private ArrayBoard(){
	}
	
	public Board initializeFromSize(int xSize, int ySize){
		//Logger.logLine(Logger.DEBUG, "Initializing new board of size " + xSize + "," + ySize);
		this.xSize = xSize;
		this.ySize = ySize;
		
		cellMatrix = new Cell[xSize][ySize];
		
		for(int x = 0; x < xSize; x++){
			for(int y = 0; y < ySize; y++){
				cellMatrix[x][y] = new Cell(x, y);
			}
		}
		
		//add all neighbours for all cells		
		for(int x = 0; x < xSize; x++){
			for(int y = 0; y < ySize; y++){		
				for(int i = x-1; i <= x+1; i++){
					for(int j = y-1; j <= y+1; j++){
						if(i == x && j==y) continue;
						if( i < 0 || j < 0 ||
							i >= xSize || j >= ySize) continue;
						//Logger.logLine("Neighbour of [" + x + ',' + y + ']' + '[' + i + ',' + j + ']');
						cellMatrix[x][y].addNeighbour(cellMatrix[i][j]);
					}
				}
			}
		}
		return this;
	
	}
	
	public int getXSize() {
		return xSize;
	}

	public int getYSize() {
		return ySize;
	}
	
	public Cell getCell(int x, int y){
		if(x >= xSize || y >= ySize) return null;
		return cellMatrix[x][y];
	}
	/**
	 * Copies the state to this board from the List given as argument
	 * @param List dataList 
	 * The source list of strings, which has the state to be copied from.
	 * This list is a list of strings, with each string representing the state of each row.
	 * @return The board, with the new state copied from the argument list, in each cell.
	 */
	@Override
	public Board copyStateFrom(List<String> dataList){
		for(int y = 0; y<ySize && y<dataList.size(); y++){
			String row = dataList.get(y);
			String [] rowElements = row.split(IConstants.SEPARATOR);
			for(int x = 0; x<xSize && x<rowElements.length; x++){
				if(rowElements[x].equals(IConstants.ALIVE_CHAR)){
					cellMatrix[x][y].setState(true);
				}
			}
		}
		return this;
	}
	
	/**
	 * Copies the state to this board from the board given as argument
	 * @Board board The source board which has the original state
	 * @return The board, with the new state copied from the argument board, in each cell.
	 */

	public Board copyStateFrom(Board board){
		//The prev generation board is 2 sizes smaller
		for(int i = 0; i < xSize-2; i++){
			for(int j = 0; j < ySize-2; j++){
				if(board.getCell(i, j).getState()){
					cellMatrix[i+1][j+1].setState(true);
				}
			}
		}
		return this;
	}
	
	public String display(){
		StringBuffer result = new StringBuffer();
		
		for(int y = 0; y < ySize; y++){
			StringBuffer line = new StringBuffer();
			for(int x = 0; x < xSize; x++){
				if(cellMatrix[x][y].isAlive()){
					line.append(IConstants.ALIVE_CHAR).append(' ');
					Logger.log(Logger.DEBUG, IConstants.ALIVE_CHAR + " ");
				} else {
					line.append(IConstants.DEAD_CHAR).append(' ');
					Logger.log(Logger.DEBUG, IConstants.DEAD_CHAR + " ");
				}
			}
			Logger.log(Logger.DEBUG, "\n");
			result.append(line.toString()).append("\n");
		}
		
		return result.toString();
	}

	@Override
	public void pruneBoard() {
		// TODO Auto-generated method stub
	}
}
