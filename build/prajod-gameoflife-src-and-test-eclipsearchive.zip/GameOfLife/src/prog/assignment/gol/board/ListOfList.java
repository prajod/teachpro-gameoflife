package prog.assignment.gol.board;

import java.util.ArrayList;
import java.util.List;

import prog.assignment.gol.IConstants;
import prog.assignment.gol.Logger;

/**
 * This class is a custom data structure to replace the 2 D matrix of the 
 * ArrayBoard. This class use a List of Lists to hold Cells. Since each row 
 * is a List, it can be pruned of unused rows after a generation is processed.
 *   
 * @author prajod
 *
 */
public class ListOfList {

	private List<ArrayList<Cell>> list;
	private int xSize, ySize;
	
	public int getXSize() {
		return xSize;
	}

	public int getYSize() {
		return ySize;
	}

	public ListOfList(int xSize, int ySize){
		this.xSize = xSize;
		this.ySize = ySize;
		list  = new ArrayList<ArrayList<Cell>>();
		
		for (int y=0; y<ySize; y++){
			ArrayList<Cell> row = new ArrayList<Cell>();
			for (int x=0; x<xSize; x++){
				Cell cell = new Cell(x, y);
				row.add(cell);
			}
			list.add(row);
		}
	}
	
	/**
	 * Get the cell object at the [x,y]th location
	 */
	public Cell getCell(int x, int y){
		if(x<0 || y<0|| x >= xSize || y >= ySize) return null;
		return list.get(y).get(x);
	}

	/**
	 * Prunes the matrix of empty rows and columns outside the live blocks 
	 */
	public void prune(){
		boolean pruneFirstRow = true;
		boolean pruneLastRow = true;
		boolean pruneFirstColumn = true;
		boolean pruneLastColumn = true;
		
		//process fist row
		for(Cell cell: list.get(0)){
			if(cell.isAlive()){
				pruneFirstRow = false;
				break;
			}
		}
		
		//process last row
		for(Cell cell: list.get(ySize-1)){
			if(cell.isAlive()){
				pruneLastRow = false;
				break;
			}
		}
		
		//process first & last columns
		for(List<Cell> row: list){
			if(row.get(0).isAlive())pruneFirstColumn = false;
			if(row.get(xSize-1).isAlive()) pruneLastColumn = false;
		}
		
		if(pruneLastRow) list.remove(ySize-1);
		if(pruneLastColumn) {
			for(List<Cell> row: list) row.remove(xSize-1);
		}
		if(pruneFirstRow) list.remove(0);
		if(pruneFirstColumn){
			for(List<Cell> row: list) row.remove(0);
		}
		
		ySize = list.size();
		xSize = list.get(0).size();
	}
	
	public String toString(){
		StringBuffer result = new StringBuffer();
		
		for(int y = 0; y < getYSize(); y++){
			StringBuffer line = new StringBuffer();
			for(int x = 0; x < getXSize(); x++){
				if(getCell(x,y).isAlive()){
					line.append(IConstants.ALIVE_CHAR).append(' ');
				} else {
					line.append(IConstants.DEAD_CHAR).append(' ');
				}
			}
			result.append(line.toString()).append("\n");
		}
		
		return result.toString();		
	}
	
}

