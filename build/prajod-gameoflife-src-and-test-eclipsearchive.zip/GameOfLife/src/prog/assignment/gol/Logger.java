package prog.assignment.gol;

import java.util.logging.Level;

public class Logger {
	
	public static final String INFO = "INFO";
	public static final String DEBUG = "DEBUG";
	private static final String logLevel = IConstants.CURRENT_LOG_LEVEL;

	/**
	 * Method to convert a log level of String type to the appropriate level
	 *  in the logging package. 
	 * @param strLevel
	 * @return
	 */
	Level convertStringToLogLevel(String strLevel){
		
		Level level= null;
		// TODO write conversion code to convert strLevel to Level here
		// There are two options: the java.util.logging package or
		// log4j package.
		
		return level;
	}
	public static void logLine(String level, String text){
		//TODO replace System.out with the appropriate log command
		if (logLevel == DEBUG) {
			System.out.println(text);
		}
		else if (logLevel == INFO){
			if (level != DEBUG)
				System.out.println(text);
		}
		
	}
	
	public static void log(String level, String text){
		//TODO replace System.out with the appropriate log command
		if (logLevel == DEBUG) {
			System.out.print(text);
		}
		else if (logLevel == INFO){
			if (level != DEBUG)
				System.out.print(text);
		}
	}

}
