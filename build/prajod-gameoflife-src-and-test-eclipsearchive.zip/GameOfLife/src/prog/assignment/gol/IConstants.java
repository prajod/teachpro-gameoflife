package prog.assignment.gol;

public interface IConstants {
	
	public final String ALIVE_CHAR = "X";
	public final String DEAD_CHAR = "-";
	public final String SEPARATOR = "\\s+";
	public final String ARRAY_BOARD = "ARRAY_BOARD";
	public final String ARRAY_LIST_BOARD = "ARRAY_LIST_BOARD";
	public final String CURRENT_BOARD = ARRAY_LIST_BOARD;
	public final String CURRENT_LOG_LEVEL = "DEBUG";
}
